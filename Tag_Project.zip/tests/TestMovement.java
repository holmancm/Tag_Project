public class TestMovement {
    public static void main(String[] args) {
        It it = new It(100, 100);
        NotIt n = new NotIt(120, 100, it);

        System.out.println("Initial positions: It=(" + it.getX() + "," + it.getY() + ") NotIt=(" + n.getX() + "," + n.getY() + ")");

        n.move(0);
        System.out.println("After NotIt.move(): NotIt=(" + n.getX() + "," + n.getY() + ")");
        if (n.getX() == 120 && n.getY() == 100) {
            System.out.println("ERROR: NotIt did not move away.");
        } else {
            System.out.println("OK: NotIt moved away from It.");
        }

        it.move(1); // UP
        System.out.println("After It.move(UP): It=(" + it.getX() + "," + it.getY() + ")");
        System.out.println("Simple tests completed.");
    }
}
