import java.awt.Graphics2D;
import java.awt.Color;

public class It implements Player {
    private double x;
    private double y;
    private int step = 10;

    public It(double startX, double startY) {
        x = startX;
        y = startY;
    }

    public double getX() { return x; }
    public double getY() { return y; }

    public void draw(Graphics2D g2d) {
        g2d.setColor(Color.RED);
        g2d.fillOval((int)x, (int)y, 25, 25);
    }

    public void move(int direction) {
        switch (direction) {
            case Directions.UP:    y -= step; break;
            case Directions.DOWN:  y += step; break;
            case Directions.LEFT:  x -= step; break;
            case Directions.RIGHT: x += step; break;
        }
    }
}
