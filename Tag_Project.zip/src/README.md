# Simple Tag - Assignment-Ready Project

## What is included
- `src/` : Java source files (no package)  
- `tests/` : Simple console tests for core logic  
- `project_testing_documentation.docx` : Testing documentation (copied into project root)  
- `Lecture 11(1).pptx` : Original lecture file you uploaded (copied into project root)

## How to compile and run (basic)
From the `src` folder:

Compile:
```
javac *.java
```

Run the game:
```
java GameFrame
```

Run tests:
```
javac ../src/*.java tests/TestMovement.java
java -cp ..:src tests.TestMovement
```

(Adjust classpath separator `:` to `;` on Windows.)

