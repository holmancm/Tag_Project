import javax.swing.*;

public class ScorePanel extends JPanel {

    private JLabel scoreLabel;
    private DisplayArea area;

    public ScorePanel(DisplayArea area) {
        this.area = area;
        scoreLabel = new JLabel("Score: 0");
        add(scoreLabel);

        Timer timer = new Timer(200, e -> {
            scoreLabel.setText("Score: " + area.getScore());
        });
        timer.start();
    }
}
