import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class GameFrame extends JFrame {

    public GameFrame() {
        setTitle("Simple Tag Game");
        setSize(800, 620);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        It itPlayer = new It(300, 300);

        ArrayList<NotIt> others = new ArrayList<>();
        others.add(new NotIt(100, 100, itPlayer));
        others.add(new NotIt(600, 100, itPlayer));

        DisplayArea gameArea = new DisplayArea(itPlayer, others);
        ScorePanel scorePanel = new ScorePanel(gameArea);

        add(gameArea, BorderLayout.CENTER);
        add(scorePanel, BorderLayout.SOUTH);

        // Ensure the panel can receive key events
        gameArea.setFocusable(true);
        gameArea.requestFocusInWindow();

        gameArea.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_UP:    itPlayer.move(Directions.UP); break;
                    case KeyEvent.VK_DOWN:  itPlayer.move(Directions.DOWN); break;
                    case KeyEvent.VK_LEFT:  itPlayer.move(Directions.LEFT); break;
                    case KeyEvent.VK_RIGHT: itPlayer.move(Directions.RIGHT); break;
                }
                gameArea.repaint();
            }
        });

        // Also allow frame-level key handling
        addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_UP:    itPlayer.move(Directions.UP); break;
                    case KeyEvent.VK_DOWN:  itPlayer.move(Directions.DOWN); break;
                    case KeyEvent.VK_LEFT:  itPlayer.move(Directions.LEFT); break;
                    case KeyEvent.VK_RIGHT: itPlayer.move(Directions.RIGHT); break;
                }
                gameArea.repaint();
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GameFrame f = new GameFrame();
            f.setVisible(true);
        });
    }
}
