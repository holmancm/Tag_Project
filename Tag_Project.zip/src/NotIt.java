import java.awt.Graphics2D;
import java.awt.Color;

public class NotIt implements Player {

    private double x;
    private double y;
    private int step = 8;
    private It itRef;

    public NotIt(double startX, double startY, It itRef) {
        this.x = startX;
        this.y = startY;
        this.itRef = itRef;
    }

    public double getX() { return x; }
    public double getY() { return y; }

    public void draw(Graphics2D g2d) {
        g2d.setColor(Color.BLUE);
        g2d.fillOval((int)x, (int)y, 25, 25);
    }

    public void move(int ignoredDirection) {
        // Move away from the It player
        double dx = x - itRef.getX();
        double dy = y - itRef.getY();

        double length = Math.sqrt(dx * dx + dy * dy);
        if (length == 0) {
            // If exactly on top, nudge to a random direction
            x += step;
            y += step;
            return;
        }

        x += (dx / length) * step;
        y += (dy / length) * step;

        // Keep within visible bounds (0..760, 0..540) assuming 800x600 window and 25px size
        if (x < 0) x = 0;
        if (y < 0) y = 0;
        if (x > 775) x = 775;
        if (y > 575) y = 575;
    }
}
