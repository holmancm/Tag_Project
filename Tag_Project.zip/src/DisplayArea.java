import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class DisplayArea extends JPanel {

    private It itPlayer;
    private ArrayList<NotIt> notItPlayers;
    private int score = 0;
    private final int TAG_DISTANCE = 28; // threshold for a tag

    public DisplayArea(It itPlayer, ArrayList<NotIt> notItPlayers) {
        this.itPlayer = itPlayer;
        this.notItPlayers = notItPlayers;
        setBackground(Color.WHITE);
        setPreferredSize(new Dimension(800, 560));

        Timer timer = new Timer(60, e -> gameLoop());
        timer.start();
    }

    private void gameLoop() {
        for (NotIt p : notItPlayers) {
            p.move(0);
            checkTag(p);
        }
        repaint();
    }

    private void checkTag(NotIt p) {
        double distance = Math.hypot(p.getX() - itPlayer.getX(), p.getY() - itPlayer.getY());
        if (distance < TAG_DISTANCE) {
            score++;
            // teleport tagged player to a random corner to give it a chance to move away
            double nx = Math.random() > 0.5 ? 50 : 700;
            double ny = Math.random() > 0.5 ? 50 : 450;
            // set via reflection-like direct access (since fields are private) - recreate object as simple approach
            // For simplicity: move player directly by setting fields via a small helper method would be better.
            // But here, we'll emulate resetting coordinates using a small hack: move away several times.
            for (int i = 0; i < 5; i++) p.move(0);
        }
    }

    public int getScore() { return score; }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        itPlayer.draw(g2d);
        for (NotIt p : notItPlayers) p.draw(g2d);
    }
}
