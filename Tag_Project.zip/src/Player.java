public interface Player {
    double getX();
    double getY();
    void move(int direction);
    void draw(java.awt.Graphics2D g2d);
}
